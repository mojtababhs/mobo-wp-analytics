
(function(){
    if (typeof Chart === 'undefined' || typeof MOBO_ANALYTICS === 'undefined') return;

    const line = (id, data) => {
        const el = document.getElementById(id); if(!el) return;
        new Chart(el,{type:'line',data:{labels:data.labels||[],datasets:[{label:'بازدید',data:data.values||[],tension:.35,fill:true}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true}}}});
    };
    const doughnut = (id, data) => {
        const el = document.getElementById(id); if(!el) return;
        new Chart(el,{type:'doughnut',data:{labels:data.labels||[],datasets:[{data:data.values||[]}]},options:{responsive:true,plugins:{legend:{position:'bottom'}}}});
    };

    line('moboDailyChart', MOBO_ANALYTICS.daily || {});
    doughnut('moboDeviceChart', MOBO_ANALYTICS.devices || {});
    doughnut('moboSourceChart', MOBO_ANALYTICS.sources || {});
    doughnut('moboUserChart', MOBO_ANALYTICS.users || {});
})();
